<?php
$config = array(
    'title' => 'SofteShop',
    'db' => array(
        'server' => 'localhost',
        'username' => 'f0545805_shop',
        'password' => 'shop',
        'name' => 'f0545805_shop'
    )
);
require "db.php";

session_start();
